'''
# TODO 01: Problem formulation
Implement a class representing the problem
'''

'''
# TODO 02: Search strategies
Implement a class with methods as search strategies
'''