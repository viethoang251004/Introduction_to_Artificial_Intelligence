from maze import MazeGraph
from search import SearchAlgorithms

def read_maze_from_file(file_path):
    with open(file_path, 'r') as file:
        maze = [line.strip() for line in file]
    return maze

def main():
    maze_file_path = input("Enter the path to the maze file: ")
    maze = read_maze_from_file(maze_file_path)

    maze_graph = MazeGraph(maze)
    food_points = maze_graph.food_points

    # Select search algorithm
    algorithm = input("Select the search algorithm (A* / UCS): ").strip().lower()

    # Validate the selected algorithm
    if algorithm not in ["a*", "ucs"]:
        print("Invalid algorithm selection.")
        return

    total_costs = []  # List to store total costs for each food point

    # Start recursion to find paths to food points
    find_paths(maze_graph, food_points, algorithm, total_costs)

    # Print the total sum of costs
    print("Total Sum of Costs:", sum(total_costs))


def find_paths(graph, food_points, algorithm, total_costs):
    if not food_points:
        return

    food_point = food_points[0]
    print("Food Point:", food_point)

    if algorithm == "a*":
        # Using A* algorithm
        path = SearchAlgorithms.a_star(graph, food_point)
    else:
        # Using UCS algorithm
        path = SearchAlgorithms.ucs(graph, graph.start, food_point)

    actions_list = get_actions_list(path)
    total_cost = len(path) - 1 if path else -1
    total_costs.append(total_cost)

    print(f"Search Algorithm: {algorithm.upper()}")
    print("Path:", path)
    print("Actions:", actions_list)
    print("Total Cost:", total_cost)
    print("-" * 50)

    # Remove the current food point and continue recursion
    graph.start = food_point
    food_points.remove(food_point)
    find_paths(graph, food_points, algorithm, total_costs)



def get_actions_list(path):
    actions_list = []
    if path:
        for i in range(len(path) - 1):
            curr_pos = path[i]
            next_pos = path[i + 1]
            if next_pos[0] < curr_pos[0]:
                actions_list.append("North")
            elif next_pos[0] > curr_pos[0]:
                actions_list.append("South")
            elif next_pos[1] < curr_pos[1]:
                actions_list.append("West")
            elif next_pos[1] > curr_pos[1]:
                actions_list.append("East")
    return actions_list


if __name__ == "__main__":
    main()
