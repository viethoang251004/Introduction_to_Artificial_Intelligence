from problem import Problem
from search import LocalSearchStrategy

def schedule1(t):
    return max(0, 100 - t)
def schedule2(t):
    return 1000 * 0.7 ** t
def main(case=1,schedule_func=schedule1):

    problem = Problem('monalisa.jpg')
    if case == 1:
        num_trials = int(input("Enter the number of trials: "))
        p1=LocalSearchStrategy.random_restart_hill_climbing(problem,num_trials)
        print("Random Restart Hill Climbing:")
    elif case == 2:
        schedule_func_input = input("Enter the schedule function (1: schedule1, 2: schedule2): ")
        schedule_func = schedule1 if schedule_func_input == "1" else schedule2
        p1=LocalSearchStrategy.simulated_annealing_search(problem,schedule_func)
        print("Simulated Annealing Search:")
    elif case == 3:
        k = int(input("Enter the number of beams: "))
        p1=LocalSearchStrategy.local_beam_search(problem,k)
        print("Local Beam Search:")
    else:
        raise ValueError("Invalid case number. Please choose a number between 1 and 3.")
    print(p1)
    problem.draw_path(p1)

if __name__ == "__main__":
    case = int(input("Enter the case number (1: Random Restart Hill Climbing, 2: Simulated Annealing Search, 3: Local Beam Search): "))
    main(case)