import random
import math
from collections import deque
class LocalSearchStrategy:
    @staticmethod
    def random_restart_hill_climbing(problem, num_trials):
        best_path = None
        best_evaluation = float('-inf')
        
        for _ in range(num_trials):
            current_state = ((39, 49))
            current_value = problem.evaluate_state(current_state)
            path = [current_state]
            
            while True:
                neighbor = problem.get_highest_valued_successor(current_state)
                neighbor_value = problem.evaluate_state(neighbor)
                
                if neighbor_value <= current_value:
                    break
                
                current_state = neighbor
                current_value = neighbor_value
                path.append(current_state)
                
            if current_value > best_evaluation:
                best_evaluation = current_value
                best_path = path
        
        xyz_list = [(state[0], state[1], problem.Z[state[1], state[0]]) for state in best_path]
        return xyz_list

    #Task 3:
    @staticmethod
    def simulated_annealing_search(problem, schedule):
        current_state = problem.get_random_state()
        path = [current_state]
        for t in range(1, 10**6):
            T = schedule(t)
            if T == 0:
                break
            
            neighbors = problem.get_successor(current_state)
            if not neighbors:
                break
            
            next_state = random.choice(neighbors)
            ΔE = problem.evaluate_state(next_state) - problem.evaluate_state(current_state)
            
            if ΔE > 0 or random.random() < math.exp(ΔE / T):
                current_state = next_state
                path.append(current_state)
        
        xyz_list = [(state[0], state[1], problem.Z[state[1], state[0]]) for state in path]
        return xyz_list
    @staticmethod
    def local_beam_search(problem, k):
        start_state = problem.get_random_state()
        beam = [start_state]  
        path = [start_state]  
        print(start_state)  
        while beam:
            new_beam = []  
            for state in beam:  
                successors = [(temp, problem.evaluate_state(temp)) for temp in problem.get_successor(state)] 
                new_beam.extend(successors) 
            new_beam.sort(key=lambda x: x[1], reverse=True)
            new_beam = new_beam[:k]  
            max_beam = new_beam[0]
            beam = [state for state, _ in new_beam] 
            if max_beam[0] not in path and max_beam[1] > problem.evaluate_state(path[-1]):
                path.append(max_beam[0])  
            else:
                break
        xyz_list = [(state[0], state[1], problem.Z[state[1], state[0]]) for state in path]
        return xyz_list







